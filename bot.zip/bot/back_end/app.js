import express from 'express';
import Run from './index.cjs';
import cors from 'cors';
const app=express();
const port=9090;
app.use(cors());
app.use(express.json());
app.get('/:data',Run);
app.listen(port,()=>{console.log(`app started at ${port}`)});